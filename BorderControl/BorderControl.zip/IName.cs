﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    interface IName:IBuyer

    {
        public string Name { get; set; }
    }
}

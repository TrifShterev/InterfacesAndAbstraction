﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
  public  interface IIdentifable
    {
        public string Id { get; set; }
    }
}
